
'use strict';
                
const Banking= require('./lib/Banking');
                                
module.exports.Banking = Banking;
module.exports.contracts = [ Banking ];