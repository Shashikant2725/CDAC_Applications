
'use strict';
                
const Finance= require('./lib/Finance');
                                
module.exports.Finance = Finance;
module.exports.contracts = [ Finance ];