
'use strict';
                
const Supplychain= require('./lib/Supplychain');
                                
module.exports.Supplychain = Supplychain;
module.exports.contracts = [ Supplychain ];