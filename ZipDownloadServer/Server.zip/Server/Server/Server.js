
        const express = require("express");
        const bodyParser = require("body-parser");
        const dbConnect = require("./config/dbConnect");
        const cors = require("cors");
        const app = express();
        const dotenv = require("dotenv").config();
        const PORT = process.env.PORT || 6000;
        const DB = require("./config/dbConnect");
        const UserRoutes = require("./routes/userRoutes");
        // const LoginRouts = require('./routes/userRoutes')
        const { notFound, errorHandler } = require("./middleware/errorHandler");
        // const { urlencoded } = require('body-parser');
        dbConnect();
        app.use(bodyParser.json());
        app.use(bodyParser.urlencoded({ extended: false }));
        
        app.use(
          cors({
            origin: "*",
          })
        ); "PostSampleLogic"
        app.listen(PORT, "10.244.3.187");
        console.log('Server listening on 10.244.3.187'); 