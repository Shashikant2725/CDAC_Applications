
'use strict';
                
const Chaincode= require('./lib/Chaincode');
                                
module.exports.Chaincode = Chaincode;
module.exports.contracts = [ Chaincode ];